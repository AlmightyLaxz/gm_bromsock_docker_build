#!/bin/bash

mkdir /output
echo "[*] Building gm_bromsock"
make -C /data/gm_bromsock
ls /data/gm_bromsock
mv /data/gm_bromsock/gmsv_bromsock_linux.so /output
ls /output
